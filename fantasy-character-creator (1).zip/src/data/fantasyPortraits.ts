import mageImg from '../assets/images/mage_portrait_1793345099083.jpg';
import mageAltImg from '../assets/images/mage_portrait_alt_1793345118738.jpg';
import warriorImg from '../assets/images/warrior_portrait_1793345099240.jpg';
import warriorAltImg from '../assets/images/warrior_portrait_alt_1793345119042.jpg';
import rogueImg from '../assets/images/rogue_portrait_1793345100332.jpg';
import rogueAltImg from '../assets/images/rogue_portrait_alt_1793345120642.jpg';
import archerImg from '../assets/images/archer_portrait_1793345100842.jpg';
import archerAltImg from '../assets/images/archer_portrait_alt_1793345120662.jpg';
import paladinImg from '../assets/images/paladin_portrait_1793345100858.jpg';
import paladinAltImg from '../assets/images/paladin_portrait_alt_1793345121538.jpg';
import necromancerImg from '../assets/images/necromancer_portrait_1793345101707.jpg';
import necromancerAltImg from '../assets/images/necromancer_portrait_alt_1793345121358.jpg';
import { CharacterClass } from './fantasyData';

export const BUILTIN_PORTRAITS: Record<CharacterClass, string[]> = {
  Mage: [mageImg, mageAltImg],
  Warrior: [warriorImg, warriorAltImg],
  Rogue: [rogueImg, rogueAltImg],
  Archer: [archerImg, archerAltImg],
  Paladin: [paladinImg, paladinAltImg],
  Necromancer: [necromancerImg, necromancerAltImg],
};

export function getBuiltinPortrait(characterClass: CharacterClass, variantIndex: number = 0): string {
  const list = BUILTIN_PORTRAITS[characterClass] || BUILTIN_PORTRAITS.Warrior;
  const idx = Math.abs(variantIndex) % list.length;
  return list[idx];
}
