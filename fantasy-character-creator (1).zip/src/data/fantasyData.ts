export type CharacterClass =
  | 'Mage'
  | 'Rogue'
  | 'Warrior'
  | 'Archer'
  | 'Paladin'
  | 'Necromancer';

export interface ClassInfo {
  name: CharacterClass;
  tagline: string;
  themeColor: string;
  badgeBg: string;
  badgeText: string;
  borderColor: string;
  iconName: string;
  description: string;
}

export const CHARACTER_CLASSES: Record<CharacterClass, ClassInfo> = {
  Mage: {
    name: 'Mage',
    tagline: 'Weaver of Arcane Mysteries',
    themeColor: 'from-violet-600 to-indigo-600',
    badgeBg: 'bg-violet-950/60',
    badgeText: 'text-violet-300',
    borderColor: 'border-violet-500/30',
    iconName: 'Wand2',
    description: 'Masters of esoteric spells, bending ancient elements and raw arcane energy.',
  },
  Rogue: {
    name: 'Rogue',
    tagline: 'Shadow in the Whispering Dark',
    themeColor: 'from-emerald-600 to-teal-700',
    badgeBg: 'bg-emerald-950/60',
    badgeText: 'text-emerald-300',
    borderColor: 'border-emerald-500/30',
    iconName: 'Footprints',
    description: 'Lethal opportunists, excelling in stealth, quick blades, and silent infiltration.',
  },
  Warrior: {
    name: 'Warrior',
    tagline: 'Unshakable Bulwark of Steel',
    themeColor: 'from-rose-600 to-amber-700',
    badgeBg: 'bg-rose-950/60',
    badgeText: 'text-rose-300',
    borderColor: 'border-rose-500/30',
    iconName: 'Sword',
    description: 'Battlefield champions clad in armor, wielding heavy blades with relentless force.',
  },
  Archer: {
    name: 'Archer',
    tagline: 'Silent Hunter of the Wilds',
    themeColor: 'from-green-600 to-lime-700',
    badgeBg: 'bg-green-950/60',
    badgeText: 'text-green-300',
    borderColor: 'border-green-500/30',
    iconName: 'Crosshair',
    description: 'Keen-eyed marksmen whose arrows find their mark across windswept plains.',
  },
  Paladin: {
    name: 'Paladin',
    tagline: 'Champion of the Radiant Oath',
    themeColor: 'from-amber-500 to-yellow-600',
    badgeBg: 'bg-amber-950/60',
    badgeText: 'text-amber-300',
    borderColor: 'border-amber-500/30',
    iconName: 'Shield',
    description: 'Devoted crusaders channeling divine grace and shielding their allies from evil.',
  },
  Necromancer: {
    name: 'Necromancer',
    tagline: 'Master of Spirits and Shadows',
    themeColor: 'from-purple-800 to-slate-900',
    badgeBg: 'bg-purple-950/60',
    badgeText: 'text-purple-300',
    borderColor: 'border-purple-500/30',
    iconName: 'Skull',
    description: 'Commanders of the undead, communing with the veil between life and eternity.',
  },
};

export const CLASS_LIST: CharacterClass[] = [
  'Mage',
  'Rogue',
  'Warrior',
  'Archer',
  'Paladin',
  'Necromancer',
];

// Rich pool of fantasy first names
export const FIRST_NAMES: string[] = [
  'Aeloria', 'Thalor', 'Vespera', 'Morgrim', 'Lyra',
  'Draven', 'Fenris', 'Seraphina', 'Kaelen', 'Sylas',
  'Rowan', 'Xander', 'Isolde', 'Balthazar', 'Eldrin',
  'Zephyra', 'Valerius', 'Cassian', 'Mirielle', 'Ignatius',
  'Rhiannon', 'Garrick', 'Thorin', 'Elyndra', 'Vivienne',
  'Thorgar', 'Astrid', 'Corvus', 'Nyx', 'Orion',
  'Branoc', 'Caelum', 'Danica', 'Evander', 'Faelan',
  'Gwyneira', 'Hadrian', 'Iolanthe', 'Jarek', 'Kaida',
  'Lumin', 'Maelis', 'Nerys', 'Othelia', 'Perseus',
  'Rhydian', 'Selene', 'Theron', 'Ursula', 'Vaelin',
  'Wynter', 'Xylos', 'Yvaine', 'Zarek', 'Eowyn',
  'Aldous', 'Berylla', 'Cyprian', 'Darian', 'Elysia'
];

// Surnames and clan names
export const SURNAMES: string[] = [
  'Silverthorn', 'Stormbringer', 'Ironheart', 'Moonwhisper', 'Flameborn',
  'Duskfall', 'Starweaver', 'Bloodfang', 'Swiftblade', 'Frostborn',
  'Sunreaver', 'Shadowalker', 'Oakenshield', 'Doomhammer', 'Nightshade',
  'Emberfall', 'Crownguard', 'Runecaster', 'Windrunner', 'Stonebreaker',
  'Lightward', 'Ravenshade', 'Wintercrest', 'Blackthorn', 'Dawnseeker',
  'Deepwood', 'Ironforge', 'Mistral', 'Grimward', 'Ashwood',
  'Valesong', 'Highborne', 'Shadowmere', 'Starfall', 'Wyrmbane'
];

// Titles and epithets
export const TITLES: string[] = [
  'the Undaunted', 'the Silent', 'the Steadfast', 'the Ashborn',
  'the Relentless', 'the Vengeful', 'the Eternal', 'the Swift',
  'the Radiant', 'the Shadowbound', 'the Unbroken', 'the Cursed',
  'of the Iron Spire', 'of the High Hollow', 'of the Northern Mist',
  'of the Lost Clan', 'the Brave', 'the Wise', 'the Ironclad',
  'the Starwatcher', 'the Whisperer', 'the Oathkeeper', 'the Storm-Crowned'
];

// Character Stats structure: Health (50-200), Mana (20-150), Strength (10-100)
export interface CharacterStats {
  health: number;
  mana: number;
  strength: number;
}

export interface GeneratedCharacter {
  id: string;
  name: string;
  characterClass: CharacterClass;
  createdAt: number;
  portraitUrl?: string;
  stats: CharacterStats;
  backstory: string;
}

// Generate random character name using combinations
export function generateRandomName(): string {
  const firstName = FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)];
  const useTitle = Math.random() < 0.35;
  if (useTitle) {
    const title = TITLES[Math.floor(Math.random() * TITLES.length)];
    return `${firstName} ${title}`;
  } else {
    const surname = SURNAMES[Math.floor(Math.random() * SURNAMES.length)];
    return `${firstName} ${surname}`;
  }
}

// Generate random character stats adhering strictly to required bounds:
// Health: 50 - 200
// Mana: 20 - 150
// Strength: 10 - 100
export function generateRandomStats(): CharacterStats {
  return {
    health: Math.floor(Math.random() * (200 - 50 + 1)) + 50,
    mana: Math.floor(Math.random() * (150 - 20 + 1)) + 20,
    strength: Math.floor(Math.random() * (100 - 10 + 1)) + 10,
  };
}

// Backstory component templates per class for rich narrative generation
const BACKSTORY_TEMPLATES: Record<CharacterClass, {
  origins: string[];
  deeds: string[];
  destinies: string[];
}> = {
  Mage: {
    origins: [
      'Trained in the astral libraries of the Sunken Citadel',
      'Orphaned during the Night of Falling Comets and raised by reclusive hermits',
      'Once the royal scholar to the King of Aethelgard before the court collapsed',
      'Awakened to raw elemental power after surviving an arcane lightning strike',
    ],
    deeds: [
      'decoded the ancient runes of the Celestial Sundial to seal an abyssal rift',
      'banished a rogue fire demon back to the molten depths of Mount Cinder',
      'crafted a legendary staff infused with the crystallized tears of a dying star',
      'unraveled a catastrophic curse that had frozen the Northern Vale in eternal winter',
    ],
    destinies: [
      'now roams the mortal realm chronicling forbidden spells to safeguard future generations.',
      'seeks the lost fragments of the Chronos Tome to restore balance to the ley lines.',
      'wields primordial ether in defense of the sanctuary against encroaching shadows.',
    ],
  },
  Warrior: {
    origins: [
      'Forged in the merciless skirmishes of the Iron Peaks',
      'Firstborn heir to a fallen banner of vanguard knights',
      'A legendary gladiator who won freedom in the sandpits of Oakhaven',
      'Sole survivor of the legendary garrison at Dragon-tooth Pass',
    ],
    deeds: [
      'shattered the war-horns of an invading barbarian clan single-handedly',
      'parried the blow of a raging mountain wyrm to protect fleeing villagers',
      'cleaved through an army of cursed armor to recover their clan’s ancestral sigil',
      'led the vanguard charge during the Siege of the Obsidian Gate',
    ],
    destinies: [
      'now fights as a steadfast guardian, swearing their blade only to righteous causes.',
      'wanders from bastion to bastion seeking worthy champions to test their martial prowess.',
      'swore an unbreakable oath of steel to shield the realm from the oncoming cataclysm.',
    ],
  },
  Rogue: {
    origins: [
      'Raised within the shadowy alleys of the Gilded Quarter',
      'A disgraced scout from the Royal Reconnaissance Guild who knows too many secrets',
      'Apprenticed to the elusive Master of the Silent Brotherhood',
      'Born under a eclipsed moon and blessed with step as silent as falling dusk',
    ],
    deeds: [
      'infiltrated the high vault of the Arch-Baron and liberated stolen elven heirlooms',
      'escaped the inescapable dungeons of the Sunken Spire without leaving a clue',
      'thwarted an imperial conspiracy by replacing a poisoned goblet in broad daylight',
      'shadowed the Dread King’s emissary across three kingdoms without ever being spotted',
    ],
    destinies: [
      'now takes contracts on their own terms, keeping balance between rival syndicates.',
      'operates from the fringes, striking down tyranny from the blind spots of power.',
      'seeks the mythical Cloak of Shrouds to erase their name from all mortal memory.',
    ],
  },
  Archer: {
    origins: [
      'Guardian of the ancient Elderwood who listened to the songs of the great oaks',
      'A wandering ranger born on the windy plains of the Whispering Steppe',
      'Trained by master falconers atop the crags of the Hawk-Eye Ridge',
      'Exiled protector of a sacred grove that was consumed by wild sorcery',
    ],
    deeds: [
      'loosed an arrow through a tempest gale to sever a siege engine’s counterweight',
      'tracked a pack of phantom wolves across frost-bitten peaks for seven fortnights',
      'defended a border watchtower with a single quiver until dawn light arrived',
      'rescued the sacred silver stag from the jaws of a corrupt chimeric beast',
    ],
    destinies: [
      'now guides travelers through perilous wilds while picking off monsters from afar.',
      'scours the frontier for signs of ancient blight, bow drawn in quiet vigilance.',
      'carries the mantle of the Wild Hunt, preserving nature’s sacred autonomy.',
    ],
  },
  Paladin: {
    origins: [
      'Anointed at dawn in the high cathedral of the Radiant Sun',
      'A battle-hardened squire who witnessed a divine epiphany upon the killing fields',
      'Descendant of the legendary Order of the Golden Aegis',
      'Reborn through sacred spring water after sacrificing their breath for a comrade',
    ],
    deeds: [
      'stood steadfast on the bridge of Eldoria against a relentless legion of undead',
      'cleansed a defiled sanctuary by channeling raw celestial light through their warhammer',
      'repelled a darkness-tainted plague with fervent prayers and restorative grace',
      'bore the blinding wrath of an unholy archon and struck the beast down in glory',
    ],
    destinies: [
      'now travels as a beacon of hope, inspiring courage in all weary hearts.',
      'purges darkness wherever it lurks, guided by the immutable tenets of the Sun.',
      'guards the innocent with an unyielding shield and righteous fury.',
    ],
  },
  Necromancer: {
    origins: [
      'A solitary scholar who peered beyond the veil of the Crypt of Despair',
      'Survivor of an ancient necrotic ritual that infused them with ghost-light',
      'Former apothecary who uncovered forgotten funerary manuscripts in the catacombs',
      'Communed with ancestral spirits who chose them as their worldly voice',
    ],
    deeds: [
      'quelled a violent spectral uprising by binding restless phantoms to rest',
      'harnessed the soul of an ancient dragon to save their hometown from ruin',
      'communed with fallen heroes of antiquity to retrieve lost battle wisdom',
      'wove ethereal wards that prevented the dead from being weaponized by tyrants',
    ],
    destinies: [
      'now maintains the delicate boundary between mortality and the ethereal beyond.',
      'seeks to redeem the forbidden arts by using death’s power to protect the living.',
      'commands spectral armies to enforce cosmic equilibrium across the twilight plane.',
    ],
  },
};

// Generate rich dynamic backstory
export function generateCharacterBackstory(name: string, characterClass: CharacterClass): string {
  const data = BACKSTORY_TEMPLATES[characterClass];
  const origin = data.origins[Math.floor(Math.random() * data.origins.length)];
  const deed = data.deeds[Math.floor(Math.random() * data.deeds.length)];
  const destiny = data.destinies[Math.floor(Math.random() * data.destinies.length)];

  return `${origin}, ${name} famously ${deed}. ${name} ${destiny}`;
}

// Generate complete character with stats and backstory
export function generateCharacter(lastGeneratedName?: string): GeneratedCharacter {
  let name = generateRandomName();
  let attempts = 0;
  while (name === lastGeneratedName && attempts < 5) {
    name = generateRandomName();
    attempts++;
  }

  const randomClass = CLASS_LIST[Math.floor(Math.random() * CLASS_LIST.length)];
  const stats = generateRandomStats();
  const backstory = generateCharacterBackstory(name, randomClass);

  return {
    id: `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    name,
    characterClass: randomClass,
    createdAt: Date.now(),
    stats,
    backstory,
  };
}
