/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useId } from 'react';
import {
  Wand2,
  Footprints,
  Sword,
  Crosshair,
  Shield,
  Skull,
  Copy,
  Check,
  Volume2,
  VolumeX,
  Dices,
  RotateCcw,
  Sparkles,
  Loader2,
  RefreshCw,
  Image as ImageIcon,
  AlertCircle,
  Info,
  Heart,
  Zap,
  Flame,
  BookmarkPlus,
  BookmarkCheck,
  Trash2,
  Eye,
  BookOpen,
} from 'lucide-react';
import {
  CHARACTER_CLASSES,
  generateCharacter,
  generateCharacterBackstory,
  type GeneratedCharacter,
  type CharacterClass,
} from './data/fantasyData';
import { getBuiltinPortrait } from './data/fantasyPortraits';
import { playSummonChime } from './utils/audio';

const STORAGE_KEY = 'fantasy_player_card_deck_v1';

// Helper to render class icon
function ClassIcon({ characterClass, className }: { characterClass: CharacterClass; className?: string }) {
  switch (characterClass) {
    case 'Mage':
      return <Wand2 className={className ?? 'w-5 h-5'} />;
    case 'Rogue':
      return <Footprints className={className ?? 'w-5 h-5'} />;
    case 'Warrior':
      return <Sword className={className ?? 'w-5 h-5'} />;
    case 'Archer':
      return <Crosshair className={className ?? 'w-5 h-5'} />;
    case 'Paladin':
      return <Shield className={className ?? 'w-5 h-5'} />;
    case 'Necromancer':
      return <Skull className={className ?? 'w-5 h-5'} />;
  }
}

export default function App() {
  const [character, setCharacter] = useState<GeneratedCharacter | null>(null);
  const [deck, setDeck] = useState<GeneratedCharacter[]>([]);
  const [history, setHistory] = useState<GeneratedCharacter[]>([]);
  const [copied, setCopied] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isGeneratingChar, setIsGeneratingChar] = useState<boolean>(false);
  const [isGeneratingPortrait, setIsGeneratingPortrait] = useState<boolean>(false);
  const [isGeneratingBackstory, setIsGeneratingBackstory] = useState<boolean>(false);
  const [portraitError, setPortraitError] = useState<string | null>(null);
  const [portraitSourceInfo, setPortraitSourceInfo] = useState<string | null>(null);
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);
  const [variantCounter, setVariantCounter] = useState<number>(0);
  const cardId = useId();

  // Load saved deck from localStorage on initial render
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          setDeck(parsed);
        }
      }
    } catch (e) {
      console.warn('Failed to load saved deck from localStorage:', e);
    }
  }, []);

  // Save deck to localStorage whenever deck changes
  const saveDeckToStorage = (updatedDeck: GeneratedCharacter[]) => {
    setDeck(updatedDeck);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedDeck));
    } catch (e) {
      console.warn('Failed to persist deck to localStorage:', e);
    }
  };

  // Generate a new random fantasy character with stats and backstory
  const handleGenerateCharacter = () => {
    setIsGeneratingChar(true);
    setPortraitError(null);
    setPortraitSourceInfo(null);
    setVariantCounter(0);
    setSaveFeedback(null);
    playSummonChime(soundEnabled);

    setTimeout(() => {
      const newChar = generateCharacter(character?.name);
      setCharacter(newChar);
      setHistory((prev) => [newChar, ...prev.slice(0, 7)]);
      setIsGeneratingChar(false);
      setCopied(false);
    }, 120);
  };

  // Generate or regenerate AI portrait for the current character (stats & backstory unchanged)
  const handleGeneratePortrait = async () => {
    if (!character || isGeneratingPortrait) return;

    setIsGeneratingPortrait(true);
    setPortraitError(null);

    const nextVariant = variantCounter + 1;
    setVariantCounter(nextVariant);

    try {
      const res = await fetch('/api/generate-portrait', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          characterName: character.name,
          characterClass: character.characterClass,
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to generate character portrait');
      }

      let chosenUrl: string;

      if (data.imageUrl) {
        chosenUrl = data.imageUrl;
        setPortraitSourceInfo(data.modelUsed ? `Live ${data.modelUsed}` : 'Live Gemini AI');
      } else {
        // Built-in AI Studio generated model asset
        chosenUrl = getBuiltinPortrait(character.characterClass, nextVariant);
        setPortraitSourceInfo('AI Studio Built-in (Permission-safe)');
      }

      const updatedCharacter: GeneratedCharacter = {
        ...character,
        portraitUrl: chosenUrl,
      };

      setCharacter(updatedCharacter);

      // Update history entry if found
      setHistory((prev) =>
        prev.map((c) => (c.id === character.id ? updatedCharacter : c))
      );

      // Also update deck if this character is currently saved in deck
      setDeck((prev) =>
        prev.map((c) => (c.id === character.id ? updatedCharacter : c))
      );
    } catch (err: unknown) {
      console.warn('Backend portrait API error, using built-in AI image asset:', err);
      const fallbackUrl = getBuiltinPortrait(character.characterClass, nextVariant);
      const updatedCharacter: GeneratedCharacter = {
        ...character,
        portraitUrl: fallbackUrl,
      };
      setCharacter(updatedCharacter);
      setPortraitSourceInfo('AI Studio Built-in (Offline fallback)');
    } finally {
      setIsGeneratingPortrait(false);
    }
  };

  // Regenerate backstory (stats and portrait remain strictly unchanged)
  const handleRegenerateBackstory = async () => {
    if (!character || isGeneratingBackstory) return;

    setIsGeneratingBackstory(true);

    try {
      const res = await fetch('/api/generate-backstory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          characterName: character.name,
          characterClass: character.characterClass,
        }),
      });

      const data = await res.json();
      let newLore = '';

      if (data.success && data.backstory) {
        newLore = data.backstory;
      } else {
        newLore = generateCharacterBackstory(character.name, character.characterClass);
      }

      const updatedCharacter: GeneratedCharacter = {
        ...character,
        backstory: newLore,
      };

      setCharacter(updatedCharacter);

      // Update history & deck if present
      setHistory((prev) =>
        prev.map((c) => (c.id === character.id ? updatedCharacter : c))
      );
      setDeck((prev) =>
        prev.map((c) => (c.id === character.id ? updatedCharacter : c))
      );
    } catch {
      // Procedural fallback
      const newLore = generateCharacterBackstory(character.name, character.characterClass);
      const updatedCharacter: GeneratedCharacter = {
        ...character,
        backstory: newLore,
      };
      setCharacter(updatedCharacter);
    } finally {
      setIsGeneratingBackstory(false);
    }
  };

  // Save the currently displayed character to "My Deck"
  const handleSaveToDeck = () => {
    if (!character) return;

    // Ensure character has a portrait before saving to deck
    const portraitToSave =
      character.portraitUrl || getBuiltinPortrait(character.characterClass, variantCounter);

    const characterToSave: GeneratedCharacter = {
      ...character,
      portraitUrl: portraitToSave,
    };

    // Check for duplicate entry by id or identical name+stats
    const isDuplicate = deck.some(
      (c) =>
        c.id === character.id ||
        (c.name === character.name &&
          c.characterClass === character.characterClass &&
          c.stats.health === character.stats.health)
    );

    if (isDuplicate) {
      setSaveFeedback('Hero is already in My Deck!');
      setTimeout(() => setSaveFeedback(null), 3000);
      return;
    }

    const updated = [characterToSave, ...deck];
    saveDeckToStorage(updated);
    setCharacter(characterToSave);

    setSaveFeedback(`Saved ${character.name} to My Deck!`);
    setTimeout(() => setSaveFeedback(null), 3500);
  };

  // Remove a character from "My Deck"
  const handleRemoveFromDeck = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const updated = deck.filter((c) => c.id !== id);
    saveDeckToStorage(updated);
  };

  // Load a character from the deck into the main card display
  const handleLoadFromDeck = (hero: GeneratedCharacter) => {
    setCharacter(hero);
    setPortraitError(null);
    setSaveFeedback(null);
    // Scroll smoothly to card stage
    window.scrollTo({ top: 120, behavior: 'smooth' });
  };

  const handleCopy = () => {
    if (!character) return;
    const textToCopy = `✦ ${character.name} ✦\nClass: ${character.characterClass}\nHP: ${character.stats.health} | MP: ${character.stats.mana} | STR: ${character.stats.strength}\n\nBackstory:\n${character.backstory}`;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isSavedInDeck =
    character &&
    deck.some(
      (c) =>
        c.id === character.id ||
        (c.name === character.name &&
          c.characterClass === character.characterClass &&
          c.stats.health === character.stats.health)
    );

  const classDetails = character ? CHARACTER_CLASSES[character.characterClass] : null;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-amber-500/25">
      {/* Top utility row */}
      <div className="w-full max-w-5xl mx-auto px-4 pt-6 flex justify-between items-center text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <span className="font-cinzel font-bold tracking-widest text-amber-500/90 text-sm">
            ✦ FANTASY PLAYER CARD GENERATOR ✦
          </span>
        </div>
        <div className="flex items-center gap-3">
          {deck.length > 0 && (
            <a
              href="#my-deck"
              className="text-xs text-amber-400 hover:text-amber-300 transition-colors flex items-center gap-1 font-semibold"
            >
              <span>My Deck ({deck.length})</span>
            </a>
          )}
          <button
            onClick={() => setSoundEnabled((prev) => !prev)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-slate-800 bg-slate-900/80 hover:bg-slate-800 text-slate-300 transition-colors cursor-pointer"
            title={soundEnabled ? 'Mute sound effects' : 'Enable sound effects'}
            aria-label={soundEnabled ? 'Mute sound effects' : 'Enable sound effects'}
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-4 h-4 text-amber-400" />
                <span>Sound On</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-slate-500" />
                <span>Sound Off</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Container */}
      <main className="w-full max-w-4xl mx-auto px-4 py-8 flex flex-col items-center">
        {/* Header section */}
        <div className="text-center mb-6">
          <h1 className="font-cinzel text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-amber-100 drop-shadow-sm mb-3">
            Fantasy Character Creator
          </h1>
          <p className="text-base sm:text-lg text-slate-300 font-medium">
            Create your own legendary hero!
          </p>
        </div>

        {/* Generate Character Button */}
        <div className="mb-8 w-full max-w-xs flex justify-center">
          <button
            onClick={handleGenerateCharacter}
            disabled={isGeneratingChar || isGeneratingPortrait || isGeneratingBackstory}
            className={`w-full group relative inline-flex items-center justify-center gap-3 px-8 py-4 text-base sm:text-lg font-bold rounded-xl transition-all duration-150 shadow-lg cursor-pointer ${
              isGeneratingChar
                ? 'bg-amber-600/70 text-amber-950 scale-98'
                : 'bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 shadow-amber-500/20 hover:shadow-amber-500/30 active:scale-98'
            } disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            <Dices
              className={`w-5 h-5 transition-transform duration-300 ${
                isGeneratingChar ? 'rotate-180 text-amber-900' : 'group-hover:rotate-45 text-amber-950'
              }`}
            />
            <span>Generate Character</span>
          </button>
        </div>

        {/* Save Confirmation Toast / Banner */}
        {saveFeedback && (
          <div className="mb-6 w-full max-w-xl p-3 rounded-xl bg-amber-950/80 border border-amber-500/50 text-amber-200 text-sm font-semibold flex items-center justify-center gap-2 shadow-lg animate-in fade-in slide-in-from-top-2 duration-200">
            <BookmarkCheck className="w-4 h-4 text-amber-400" />
            <span>{saveFeedback}</span>
          </div>
        )}

        {/* FEATURE 1: Fantasy Trading / Player Card */}
        <section
          id={cardId}
          aria-live="polite"
          className="w-full max-w-2xl relative transition-all duration-300"
        >
          {character && classDetails ? (
            /* Ornate Golden-Bordered Trading Card */
            <div className="relative rounded-3xl p-1 bg-gradient-to-b from-amber-400 via-amber-600 to-amber-800 shadow-[0_0_35px_rgba(245,158,11,0.2)]">
              {/* Inner card surface */}
              <div className="relative rounded-[22px] bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 border border-amber-400/30 p-6 sm:p-8 overflow-hidden">
                {/* Decorative golden corner filigrees */}
                <span className="absolute top-3 left-4 text-amber-400/60 text-lg select-none">✦</span>
                <span className="absolute top-3 right-4 text-amber-400/60 text-lg select-none">✦</span>
                <span className="absolute bottom-3 left-4 text-amber-400/60 text-lg select-none">✦</span>
                <span className="absolute bottom-3 right-4 text-amber-400/60 text-lg select-none">✦</span>

                {/* Card Top Ribbon: Rarity and Class Badge */}
                <div className="flex items-center justify-between border-b border-amber-500/20 pb-4 mb-6">
                  <div className="flex items-center gap-2">
                    <span className="font-cinzel text-[11px] sm:text-xs font-black tracking-widest text-amber-400 uppercase">
                      ✦ LEGENDARY PLAYER CARD ✦
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleCopy}
                      className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors py-1 px-2.5 rounded-lg border border-slate-800 hover:border-slate-700 bg-slate-950/60 cursor-pointer"
                      title="Copy Card Lore & Stats"
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400 font-medium">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Card Main Stage: Portrait + Hero Header */}
                <div className="flex flex-col items-center">
                  {/* Portrait Frame with Ornate Golden Border */}
                  <div className="relative group w-full max-w-[280px] aspect-square rounded-2xl p-1 bg-gradient-to-b from-amber-400 via-amber-600 to-amber-700 shadow-xl overflow-hidden mb-4">
                    <div className="w-full h-full rounded-[14px] bg-slate-950 overflow-hidden relative flex items-center justify-center">
                      {isGeneratingPortrait ? (
                        /* Loading state */
                        <div className="flex flex-col items-center justify-center p-6 text-center space-y-3">
                          <div className="relative">
                            <Loader2 className="w-10 h-10 text-amber-400 animate-spin" />
                            <Sparkles className="w-4 h-4 text-amber-200 absolute -top-1 -right-1 animate-pulse" />
                          </div>
                          <p className="text-xs sm:text-sm font-semibold text-amber-200">
                            Painting Portrait...
                          </p>
                          <p className="text-[11px] text-slate-400 leading-tight">
                            Synthesizing {character.characterClass} concept art
                          </p>
                        </div>
                      ) : character.portraitUrl ? (
                        /* Rendered image */
                        <img
                          src={character.portraitUrl}
                          alt={`Portrait of ${character.name}, a ${character.characterClass}`}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                      ) : (
                        /* Placeholder before portrait generation */
                        <div className="flex flex-col items-center justify-center p-6 text-center space-y-3">
                          <div className="w-14 h-14 rounded-xl bg-slate-800/80 border border-slate-700/60 flex items-center justify-center text-slate-400">
                            <ImageIcon className="w-7 h-7 text-slate-500" />
                          </div>
                          <p className="text-xs text-slate-400">
                            No portrait generated yet
                          </p>
                        </div>
                      )}

                      {/* Class icon watermark in corner */}
                      <div className="absolute top-2 right-2 p-1.5 rounded-lg bg-slate-950/80 border border-amber-500/30 text-amber-300">
                        <ClassIcon characterClass={character.characterClass} className="w-4 h-4" />
                      </div>
                    </div>
                  </div>

                  {/* Portrait Action Controls */}
                  <div className="w-full max-w-[280px] mb-6 flex flex-col items-center">
                    {character.portraitUrl ? (
                      /* Regenerate Portrait Button */
                      <button
                        onClick={handleGeneratePortrait}
                        disabled={isGeneratingPortrait || isGeneratingChar}
                        className="w-full inline-flex items-center justify-center gap-2 py-2 px-4 rounded-xl text-xs sm:text-sm font-semibold bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 hover:border-amber-500/50 transition-colors shadow-sm cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingPortrait ? 'animate-spin' : ''}`} />
                        <span>Regenerate Portrait</span>
                      </button>
                    ) : (
                      /* Generate Portrait Button */
                      <button
                        onClick={handleGeneratePortrait}
                        disabled={isGeneratingPortrait || isGeneratingChar}
                        className="w-full inline-flex items-center justify-center gap-2 py-2 px-4 rounded-xl text-xs sm:text-sm font-bold bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 transition-all shadow-md shadow-amber-500/10 active:scale-98 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Sparkles className="w-4 h-4 text-amber-950" />
                        <span>Generate Portrait</span>
                      </button>
                    )}

                    {portraitSourceInfo && (
                      <div className="mt-1.5 flex items-center gap-1.5 text-[11px] text-slate-400">
                        <Info className="w-3 h-3 text-amber-400 shrink-0" />
                        <span>{portraitSourceInfo}</span>
                      </div>
                    )}

                    {portraitError && (
                      <div className="mt-2 w-full p-2.5 rounded-lg bg-rose-950/50 border border-rose-800/60 text-rose-300 text-xs flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                        <span className="text-[11px] text-rose-200/80 leading-tight">
                          {portraitError}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Character Name & Class Lockup */}
                  <div className="text-center w-full mb-6">
                    <h2 className="font-cinzel text-2xl sm:text-3xl md:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-100 via-amber-300 to-amber-100 tracking-wide break-words drop-shadow-sm mb-2">
                      {character.name}
                    </h2>

                    <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-amber-500/30 bg-slate-900/90 text-amber-300 text-sm font-bold shadow-inner">
                      <ClassIcon characterClass={character.characterClass} className="w-4 h-4 text-amber-400" />
                      <span>{character.characterClass}</span>
                      <span className="text-slate-500 font-normal">·</span>
                      <span className="text-xs text-slate-300 font-medium italic">
                        {classDetails.tagline}
                      </span>
                    </div>
                  </div>

                  {/* FEATURE 2: Character Statistics */}
                  <div className="w-full bg-slate-950/80 border border-amber-500/20 rounded-2xl p-4 sm:p-5 mb-6 shadow-inner">
                    <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-2">
                      <span className="font-cinzel text-xs font-bold tracking-wider text-amber-400 uppercase">
                        Combat Statistics
                      </span>
                      <span className="text-[11px] text-slate-500">
                        Randomly Generated
                      </span>
                    </div>

                    <div className="space-y-3.5">
                      {/* Health Stat: 50-200 */}
                      <div>
                        <div className="flex items-center justify-between text-xs sm:text-sm font-semibold mb-1">
                          <span className="flex items-center gap-1.5 text-rose-400">
                            <Heart className="w-4 h-4 fill-rose-500/20 text-rose-400" />
                            <span>Health</span>
                          </span>
                          <span className="font-mono tabular-nums text-slate-200">
                            {character.stats.health} <span className="text-slate-500 font-normal">/ 200 HP</span>
                          </span>
                        </div>
                        <div className="w-full h-2.5 rounded-full bg-slate-900 border border-slate-800 overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-rose-600 via-rose-500 to-rose-400 rounded-full transition-all duration-500"
                            style={{ width: `${Math.min(100, (character.stats.health / 200) * 100)}%` }}
                          />
                        </div>
                      </div>

                      {/* Mana Stat: 20-150 */}
                      <div>
                        <div className="flex items-center justify-between text-xs sm:text-sm font-semibold mb-1">
                          <span className="flex items-center gap-1.5 text-cyan-400">
                            <Zap className="w-4 h-4 fill-cyan-500/20 text-cyan-400" />
                            <span>Mana</span>
                          </span>
                          <span className="font-mono tabular-nums text-slate-200">
                            {character.stats.mana} <span className="text-slate-500 font-normal">/ 150 MP</span>
                          </span>
                        </div>
                        <div className="w-full h-2.5 rounded-full bg-slate-900 border border-slate-800 overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-blue-600 via-cyan-500 to-cyan-400 rounded-full transition-all duration-500"
                            style={{ width: `${Math.min(100, (character.stats.mana / 150) * 100)}%` }}
                          />
                        </div>
                      </div>

                      {/* Strength Stat: 10-100 */}
                      <div>
                        <div className="flex items-center justify-between text-xs sm:text-sm font-semibold mb-1">
                          <span className="flex items-center gap-1.5 text-amber-400">
                            <Flame className="w-4 h-4 fill-amber-500/20 text-amber-400" />
                            <span>Strength</span>
                          </span>
                          <span className="font-mono tabular-nums text-slate-200">
                            {character.stats.strength} <span className="text-slate-500 font-normal">/ 100 STR</span>
                          </span>
                        </div>
                        <div className="w-full h-2.5 rounded-full bg-slate-900 border border-slate-800 overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-400 rounded-full transition-all duration-500"
                            style={{ width: `${Math.min(100, (character.stats.strength / 100) * 100)}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Character Backstory Lore Section */}
                  <div className="w-full bg-slate-950/70 border border-slate-800/80 rounded-2xl p-4 sm:p-5 mb-6">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-cinzel text-xs font-bold tracking-wider text-amber-400 uppercase flex items-center gap-1.5">
                        <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                        <span>Heroic Backstory</span>
                      </span>
                      <button
                        onClick={handleRegenerateBackstory}
                        disabled={isGeneratingBackstory}
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-400 hover:text-amber-300 hover:underline transition-colors cursor-pointer disabled:opacity-50"
                        title="Regenerate only backstory lore (keeps stats & portrait)"
                      >
                        <RotateCcw className={`w-3 h-3 ${isGeneratingBackstory ? 'animate-spin' : ''}`} />
                        <span>Regenerate Backstory</span>
                      </button>
                    </div>

                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed italic">
                      "{character.backstory}"
                    </p>
                  </div>

                  {/* FEATURE 3: Save to Deck Prominent Button */}
                  <div className="w-full pt-2 flex flex-col sm:flex-row items-center gap-3">
                    <button
                      onClick={handleSaveToDeck}
                      className={`w-full flex-1 inline-flex items-center justify-center gap-2 py-3 px-6 rounded-xl text-sm sm:text-base font-bold transition-all duration-200 shadow-md cursor-pointer ${
                        isSavedInDeck
                          ? 'bg-emerald-950 border border-emerald-500/50 text-emerald-300 hover:bg-emerald-900'
                          : 'bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 shadow-amber-500/20 active:scale-98'
                      }`}
                    >
                      {isSavedInDeck ? (
                        <>
                          <BookmarkCheck className="w-5 h-5 text-emerald-400" />
                          <span>In My Deck ({deck.length})</span>
                        </>
                      ) : (
                        <>
                          <BookmarkPlus className="w-5 h-5 text-amber-950" />
                          <span>Save to Deck</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={handleGenerateCharacter}
                      disabled={isGeneratingChar || isGeneratingPortrait}
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 py-3 px-5 rounded-xl text-xs sm:text-sm font-semibold bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 hover:border-amber-500/40 transition-colors cursor-pointer disabled:opacity-50"
                    >
                      <RotateCcw className="w-4 h-4 text-amber-400" />
                      <span>Roll Another Hero</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Empty state prior to generating character */
            <div className="text-center py-12 px-6 rounded-3xl bg-slate-900/80 border-2 border-dashed border-amber-500/30">
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-slate-800/50 border border-slate-700/60 flex items-center justify-center text-amber-400/80">
                <Dices className="w-8 h-8" />
              </div>
              <h2 className="font-cinzel text-xl sm:text-2xl font-bold text-slate-200 mb-2">
                No Player Card Summoned Yet
              </h2>
              <p className="text-sm text-slate-400 max-w-md mx-auto mb-6">
                Click the <strong className="text-amber-300 font-semibold">Generate Character</strong> button above to reveal a bordered fantasy player card complete with unique combat stats, backstory lore, and portrait generator.
              </p>
              <button
                onClick={handleGenerateCharacter}
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-bold rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-md transition-all cursor-pointer"
              >
                <Dices className="w-4 h-4 text-slate-950" />
                <span>Begin Generation</span>
              </button>
            </div>
          )}
        </section>

        {/* FEATURE 4: MY DECK COLLECTION */}
        <section id="my-deck" className="w-full mt-16 pt-10 border-t border-amber-500/20">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-8">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-cinzel text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 to-amber-400">
                  My Deck
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/10 border border-amber-500/30 text-amber-300 font-mono">
                  {deck.length} {deck.length === 1 ? 'Hero' : 'Heroes'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Your saved collection of custom fantasy trading cards, preserved in browser storage.
              </p>
            </div>

            {deck.length > 0 && (
              <button
                onClick={() => {
                  if (window.confirm('Are you sure you want to clear your entire deck?')) {
                    saveDeckToStorage([]);
                  }
                }}
                className="self-start sm:self-auto text-xs text-rose-400/80 hover:text-rose-300 transition-colors cursor-pointer py-1 px-2.5 rounded border border-rose-900/60 bg-rose-950/20"
              >
                Clear Entire Deck
              </button>
            )}
          </div>

          {deck.length === 0 ? (
            /* Friendly empty-state for My Deck */
            <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-8 sm:p-12 text-center">
              <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-center text-amber-400/70">
                <BookmarkPlus className="w-7 h-7" />
              </div>
              <h3 className="font-cinzel text-lg sm:text-xl font-bold text-slate-200 mb-2">
                Your Deck is Currently Empty
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto mb-5 leading-relaxed">
                Roll a hero on the card generator above, customize their portrait and backstory, then click <strong className="text-amber-300 font-semibold">Save to Deck</strong> to build your roster of legendary adventurers.
              </p>
              <button
                onClick={handleGenerateCharacter}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs sm:text-sm font-semibold bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 transition-colors cursor-pointer"
              >
                <Dices className="w-4 h-4" />
                <span>Create First Card</span>
              </button>
            </div>
          ) : (
            /* Grid of Saved Trading Cards */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {deck.map((hero) => {
                const cDetails = CHARACTER_CLASSES[hero.characterClass];
                const isSelected = character?.id === hero.id;

                return (
                  <div
                    key={hero.id}
                    onClick={() => handleLoadFromDeck(hero)}
                    className={`group relative rounded-2xl p-0.5 transition-all duration-300 cursor-pointer ${
                      isSelected
                        ? 'bg-gradient-to-b from-amber-400 via-amber-500 to-amber-600 shadow-[0_0_20px_rgba(245,158,11,0.3)] scale-[1.02]'
                        : 'bg-gradient-to-b from-slate-700 via-slate-800 to-slate-900 hover:from-amber-500/50 hover:to-amber-700/50 hover:shadow-lg'
                    }`}
                  >
                    <div className="rounded-[14px] bg-slate-950 p-4 flex flex-col justify-between h-full relative overflow-hidden">
                      {/* Top bar with class badge & remove button */}
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-[10px] uppercase font-bold tracking-wider text-amber-400/90 font-cinzel">
                          ✦ {hero.characterClass}
                        </span>
                        <button
                          onClick={(e) => handleRemoveFromDeck(hero.id, e)}
                          className="text-slate-500 hover:text-rose-400 p-1 rounded-md transition-colors cursor-pointer"
                          title="Remove from Deck"
                          aria-label={`Remove ${hero.name} from Deck`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Portrait preview */}
                      <div className="relative w-full aspect-square rounded-xl overflow-hidden border border-amber-500/20 bg-slate-900 mb-3">
                        {hero.portraitUrl ? (
                          <img
                            src={hero.portraitUrl}
                            alt={hero.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-slate-600">
                            <ImageIcon className="w-8 h-8" />
                          </div>
                        )}
                        <div className="absolute top-2 left-2 p-1 rounded bg-slate-950/80 border border-slate-700 text-amber-300">
                          <ClassIcon characterClass={hero.characterClass} className="w-3.5 h-3.5" />
                        </div>
                      </div>

                      {/* Hero Name */}
                      <div className="mb-3">
                        <h4 className="font-cinzel text-base font-bold text-white group-hover:text-amber-200 transition-colors truncate">
                          {hero.name}
                        </h4>
                        <p className="text-[11px] text-slate-400 truncate">
                          {cDetails.tagline}
                        </p>
                      </div>

                      {/* Combat Stats Indicators */}
                      <div className="bg-slate-900/80 rounded-xl p-2.5 mb-3 border border-slate-800/80 space-y-1.5 text-[11px]">
                        {/* HP */}
                        <div className="flex items-center justify-between font-semibold">
                          <span className="text-rose-400 flex items-center gap-1">
                            <Heart className="w-3 h-3" /> HP
                          </span>
                          <span className="font-mono text-slate-200 tabular-nums">
                            {hero.stats.health} <span className="text-slate-500 font-normal">/ 200</span>
                          </span>
                        </div>
                        <div className="w-full h-1.5 rounded-full bg-slate-950 overflow-hidden">
                          <div
                            className="h-full bg-rose-500 rounded-full"
                            style={{ width: `${Math.min(100, (hero.stats.health / 200) * 100)}%` }}
                          />
                        </div>

                        {/* MP */}
                        <div className="flex items-center justify-between font-semibold">
                          <span className="text-cyan-400 flex items-center gap-1">
                            <Zap className="w-3 h-3" /> MP
                          </span>
                          <span className="font-mono text-slate-200 tabular-nums">
                            {hero.stats.mana} <span className="text-slate-500 font-normal">/ 150</span>
                          </span>
                        </div>
                        <div className="w-full h-1.5 rounded-full bg-slate-950 overflow-hidden">
                          <div
                            className="h-full bg-cyan-500 rounded-full"
                            style={{ width: `${Math.min(100, (hero.stats.mana / 150) * 100)}%` }}
                          />
                        </div>

                        {/* STR */}
                        <div className="flex items-center justify-between font-semibold">
                          <span className="text-amber-400 flex items-center gap-1">
                            <Flame className="w-3 h-3" /> STR
                          </span>
                          <span className="font-mono text-slate-200 tabular-nums">
                            {hero.stats.strength} <span className="text-slate-500 font-normal">/ 100</span>
                          </span>
                        </div>
                        <div className="w-full h-1.5 rounded-full bg-slate-950 overflow-hidden">
                          <div
                            className="h-full bg-amber-500 rounded-full"
                            style={{ width: `${Math.min(100, (hero.stats.strength / 100) * 100)}%` }}
                          />
                        </div>
                      </div>

                      {/* Card Bottom CTA */}
                      <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-amber-400 font-semibold">
                        <span className="flex items-center gap-1 group-hover:underline">
                          <Eye className="w-3.5 h-3.5" />
                          <span>View on Stage</span>
                        </span>
                        <span className="text-[10px] text-slate-500 font-normal font-mono">
                          {new Date(hero.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* Recently Generated Roster Session Drawer */}
        {history.length > 1 && (
          <section className="w-full mt-10 bg-slate-900/40 border border-slate-800/60 rounded-xl p-4 sm:p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs uppercase tracking-wider font-semibold text-slate-400">
                Session Rolls ({history.length} Heroes)
              </h3>
              <button
                onClick={() => setHistory(character ? [character] : [])}
                className="text-xs text-slate-500 hover:text-slate-400 transition-colors cursor-pointer"
              >
                Clear Rolls
              </button>
            </div>
            <div className="divide-y divide-slate-800/60">
              {history.map((hero, idx) => (
                <div
                  key={hero.id}
                  onClick={() => {
                    setCharacter(hero);
                    setPortraitError(null);
                  }}
                  className={`py-2 px-2.5 flex items-center justify-between rounded-lg cursor-pointer transition-colors ${
                    character?.id === hero.id
                      ? 'bg-slate-800/80 text-amber-200'
                      : 'hover:bg-slate-800/40 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate pr-2">
                    <span className="text-xs text-slate-500 font-mono w-4">#{idx + 1}</span>
                    {hero.portraitUrl && (
                      <img
                        src={hero.portraitUrl}
                        alt=""
                        className="w-5 h-5 rounded-full object-cover border border-amber-500/40 shrink-0"
                      />
                    )}
                    <span className="font-medium text-sm truncate">{hero.name}</span>
                  </div>
                  <div className="flex items-center gap-3 shrink-0 text-xs">
                    <span className="text-rose-400 font-mono">{hero.stats.health}HP</span>
                    <span className="px-2 py-0.5 rounded border border-slate-700 bg-slate-900 text-amber-300">
                      {hero.characterClass}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </main>

      {/* Footer */}
      <footer className="w-full text-center py-6 text-xs text-slate-500 border-t border-slate-900">
        <p>Fantasy Character Creator · Legendary Player Card Generator & Deck Builder</p>
      </footer>
    </div>
  );
}
